# Example Package

A small package to calculate minimum cost.

You can use [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.