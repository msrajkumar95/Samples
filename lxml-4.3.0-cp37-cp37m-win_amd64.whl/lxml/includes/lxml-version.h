#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "4.3.0"
#endif
