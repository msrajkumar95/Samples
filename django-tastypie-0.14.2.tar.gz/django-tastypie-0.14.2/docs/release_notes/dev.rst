dev
===

The current in-progress version. Put your notes here so they can be easily
copied to the release notes for the next release.

Major changes
-------------

* Dropped support for Django 1.8 (EOL).
* Compatability fixes for upstream changes, most notably the removal of QUERY_TERMS.

Bugfixes
--------

* Example Bugfix (Closes #PR_Number)
