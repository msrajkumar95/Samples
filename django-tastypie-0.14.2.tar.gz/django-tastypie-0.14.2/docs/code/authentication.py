import mock


OAuth20Authentication = mock.Mock()
