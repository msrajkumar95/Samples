import mock

from django.contrib.auth.models import User  # flake8: noqa


Choice = mock.MagicMock()
Poll = mock.MagicMock()
MyModel = mock.MagicMock()
